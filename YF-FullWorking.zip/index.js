
const readline = require('readline');
const colors = require('./modules/colors');
const { addAccount,listAccounts } = require('./modules/accountManager');
const { addGroup,listGroups } = require('./modules/groupManager');
const { joinGroups } = require('./modules/groupJoiner');

const rl = readline.createInterface({input:process.stdin,output:process.stdout});
const prompt = (q)=>new Promise(r=>rl.question(q,r));

async function mainMenu(){
  console.log(colors.cyan('=== YF Full Working Auto Joiner ==='));
  console.log('1) Add Account');
  console.log('2) List Accounts');
  console.log('3) Add Group');
  console.log('4) List Groups');
  console.log('5) Join Groups');
  console.log('0) Exit');
  const choice = await prompt('> ');
  switch(choice){
    case '1': await addAccount(prompt); break;
    case '2': listAccounts(); break;
    case '3': await addGroup(prompt); break;
    case '4': listGroups(); break;
    case '5': await joinGroups(); break;
    case '0': rl.close(); process.exit(0);
    default: console.log('❌ Invalid choice');
  }
  mainMenu();
}

mainMenu();
