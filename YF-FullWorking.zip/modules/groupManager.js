
const path = require('path');
const { loadJSON, saveJSON } = require('./utils');
const groupsFile = path.join(__dirname,'../data/groups.json');

async function addGroup(prompt){
  const id = await prompt('Group ID: ');
  const name = await prompt('Group Name: ');
  const groups = loadJSON(groupsFile);
  groups.push({id,name});
  saveJSON(groupsFile,groups);
  console.log('✅ Group added!');
}

function listGroups(){
  const groups = loadJSON(groupsFile);
  if(groups.length===0){console.log('⚠️ No groups');return;}
  groups.forEach((g,i)=>console.log(`${i+1}) ${g.name} (${g.id})`));
}

module.exports = {addGroup,listGroups};
