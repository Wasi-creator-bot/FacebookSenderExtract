
module.exports = {
  green: txt => `\x1b[32m${txt}\x1b[0m`,
  red: txt => `\x1b[31m${txt}\x1b[0m`,
  cyan: txt => `\x1b[36m${txt}\x1b[0m`,
  yellow: txt => `\x1b[33m${txt}\x1b[0m`
};
