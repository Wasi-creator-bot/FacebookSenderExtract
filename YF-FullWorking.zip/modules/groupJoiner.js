
const { loadJSON, saveJSON } = require('./utils');
const path = require('path');

async function joinGroups(){
  const accountsFile = path.join(__dirname,'../data/accounts.json');
  const groupsFile = path.join(__dirname,'../data/groups.json');
  const accounts = loadJSON(accountsFile);
  const groups = loadJSON(groupsFile);
  if(accounts.length===0||groups.length===0){
    console.log('⚠️ Accounts or groups missing'); return;
  }
  for(const acc of accounts){
    for(const grp of groups){
      console.log(`✅ ${acc.uid} joined ${grp.name}`);
      await new Promise(r=>setTimeout(r,500));
    }
  }
  console.log('🚀 All joins simulated!');
}

module.exports = {joinGroups};
