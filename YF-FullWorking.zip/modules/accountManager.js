
const path = require('path');
const { loadJSON, saveJSON } = require('./utils');
const accountsFile = path.join(__dirname,'../data/accounts.json');

async function addAccount(prompt){
  const uid = await prompt('UID: ');
  const password = await prompt('Password: ');
  const accounts = loadJSON(accountsFile);
  accounts.push({uid,password});
  saveJSON(accountsFile,accounts);
  console.log('✅ Account added!');
}

function listAccounts(){
  const accounts = loadJSON(accountsFile);
  if(accounts.length===0){console.log('⚠️ No accounts');return;}
  accounts.forEach((a,i)=>console.log(`${i+1}) ${a.uid}`));
}

module.exports = {addAccount,listAccounts};
