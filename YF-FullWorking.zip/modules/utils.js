
const fs = require('fs');
const path = require('path');

function loadJSON(file, def=[]) {
  if (!fs.existsSync(file)) return def;
  return JSON.parse(fs.readFileSync(file,'utf8'));
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data,null,2));
}

module.exports = { loadJSON, saveJSON };
